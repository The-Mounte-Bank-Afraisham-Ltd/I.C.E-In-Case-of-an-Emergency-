module.exports = {
    extends: "@mozilla-protocol/eslint-config",
};
